import matplotlib.pyplot as plt                   # the charting library
x = data["Annual Income (k$)"]                    # x-axis column
y = data["Spending Score (1-100)"]                # y-axis column
plt.scatter(x, y, c=model.labels_, cmap="tab10", s=30)  # colour each dot by its group
cen = model.cluster_centers_                      # the 5 group centres
plt.scatter(cen[:,0], cen[:,1], marker="X", s=200, c="black")  # mark the centres
plt.xlabel("income (k$)"); plt.ylabel("spending score")  # axis labels
plt.title("5 customer groups"); plt.show()