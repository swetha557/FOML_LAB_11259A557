import numpy as np                                # fast maths
import gymnasium as gym                           # the game world
game = gym.make("CliffWalking-v1")                # the cliff grid
Q = np.zeros((48, 4))                             # 48 squares x 4 moves
for round in range(2000):                         # play 2000 practice games
    state, _ = game.reset()                       # start at the beginning
    done = False                                  # not finished yet
    while not done:                               # keep moving until the game ends
        if np.random.rand() < 0.2:                # 20% of the time: explore
            move = game.action_space.sample()     # pick a random move
        else:                                     # otherwise: use the best known move
            move = np.random.choice(np.flatnonzero(Q[state] == Q[state].max()))  # FIX: best move for this square
        new_state, reward, done, _, _ = game.step(move)  # make the move, see the result
        Q[state, move] += 0.8 * (reward + 0.95 * np.max(Q[new_state]) - Q[state, move])  # learn: update the score
        state = new_state                         # move to the new square
print("Training done. The agent has learned the path.")  # finished learning

arrows = ["up", "right", "down", "left"]          # CAREFUL: move order is different in this game
for square in [36, 24, 30, 35]:                   # start, top-left side, middle, just above the goal
    best = np.argmax(Q[square])                   # best move for that square
    print("From square", square, "-> best move:", arrows[best])  # show it