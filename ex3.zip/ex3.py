
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Load dataset
data = pd.read_csv("mpg.csv")

# Remove missing values
data = data.dropna()

# Select input features
X = data[["cylinders", "displacement", "horsepower",
          "weight", "acceleration", "model_year"]]

# Select target variable
y = data["mpg"]

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=1
)

# Create model
model = LinearRegression()

# Train model
model.fit(X_train, y_train)

# Calculate accuracy score
print("R2 score:", round(model.score(X_test, y_test), 3))

# Predict new car mileage
new_car = pd.DataFrame(
    [[4, 120, 90, 2500, 16, 80]],
    columns=X.columns
)

mpg = model.predict(new_car)[0]

print("Predicted mileage:", round(mpg, 1), "mpg")
