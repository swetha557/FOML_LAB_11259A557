import pandas as pd                               # tables
from sklearn.cluster import AgglomerativeClustering  # the tree-based grouping model
data = pd.read_csv("StudentsPerformance.csv")     # load the CSV (capital S and P - type it exactly)
X = data[["math score","reading score"]]          # group students by their math and reading marks
model = AgglomerativeClustering(n_clusters=5)     # ask for 5 groups from the tree
data["Group"] = model.fit_predict(X)              # find groups and save each row's group
print(data.groupby("Group")[X.columns].mean())    # average of each group

new_student = [85, 90]                            # one new student: 85 in math, 90 in reading
averages = data.groupby("Group")[X.columns].mean()  # centre (average) of each group
distances = ((averages - new_student) ** 2).sum(axis=1)  # squared distance to each centre
print("Closest group:", distances.idxmin())       # the nearest group wins