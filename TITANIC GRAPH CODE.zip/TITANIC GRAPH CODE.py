import matplotlib.pyplot as plt                   # the charting library
raw = pd.read_csv("titanic.csv")[["survived","pclass","sex","age","fare","embarked"]]  # the same 6 columns again, BEFORE cleaning
blanks = raw.isnull().sum()                       # empty cells in each column
plt.bar(blanks.index, blanks.values, color="#2F49D1")  # one bar per column
plt.xticks(rotation=30); plt.ylabel("empty cells")  # tilt the names so they fit
plt.title("Empty cells before cleaning (after cleaning: 0)")  # title
plt.tight_layout(); plt.show()                    # display the graph