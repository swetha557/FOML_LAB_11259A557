
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# Load the Iris dataset
X, y = load_iris(return_X_y=True)

# Split the dataset into training and testing data
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=1
)

# Create the KNN model
model = KNeighborsClassifier(n_neighbors=5)

# Train the model
model.fit(X_train, y_train)

# Calculate accuracy
print("Accuracy:", model.score(X_test, y_test))

# Predict on new data
species = ["setosa", "versicolor", "virginica"]
new_flower = [[5.1, 3.5, 1.4, 0.2]]

answer = model.predict(new_flower)[0]

# Display the predicted flower
print("This flower is:", species[answer])


