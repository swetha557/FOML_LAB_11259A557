
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC

# Load the dataset
data = pd.read_csv("Social_Network_Ads.csv")

# Select input and output columns
X = data[["Age", "EstimatedSalary"]]
y = data["Purchased"]

# Split the dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=1
)

# Feature scaling
scaler = StandardScaler()

X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# KNN Classification
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)

knn_accuracy = knn.score(X_test, y_test)

print("KNN Accuracy:", round(knn_accuracy, 2))

# SVM Classification
svm = SVC()
svm.fit(X_train, y_train)

svm_accuracy = svm.score(X_test, y_test)

print("SVM Accuracy:", round(svm_accuracy, 2))

