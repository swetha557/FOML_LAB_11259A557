import matplotlib.pyplot as plt                   # the charting library
import numpy as np                                # for the trend line
w = data["weight"]; m = data["mpg"]               # x-axis column and y-axis column
plt.scatter(w, m, alpha=0.5, color="#2F49D1", label="cars")  # each dot = one row
a, b = np.polyfit(w, m, 1)                        # best-fit straight line
plt.plot(w, a*w + b, color="red", linewidth=2, label="trend line")  # draw the line
plt.xlabel("weight (lbs)"); plt.ylabel("mpg")     # axis labels
plt.title("Heavier cars get fewer mpg"); plt.legend()  # title and legend
plt.show()